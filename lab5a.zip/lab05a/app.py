from flask import Flask
from controllers import user_controllers
from models import user_models

app = Flask(__name__)
app.secret_key = 'secret_key'

app.register_blueprint(user_controllers.app)

if __name__ == '__main__':
    user_models.init_db()
    app.run(debug=True)


